tasks = open('todos.txt')
for chore in tasks:
    print(chore)
    tasks.close()